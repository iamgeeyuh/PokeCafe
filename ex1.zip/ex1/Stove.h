#ifndef STOVE_H
#define STOVE_H

#include "Entity.h"

struct GameState;

class Stove : public Entity {
private:
    DishType m_current_dish;
    GameState* m_game_state;
    bool is_cooking = false;
    Entity* m_order = nullptr;
    
public:

    Stove(GLuint texture_id, glm::vec3 position, float width, float height, GameState* game_state);

    void cook_order();
    void finish_order();
    void interact() override;
    
    bool get_is_cooking() {return is_cooking;}
};

#endif // STOVE_H

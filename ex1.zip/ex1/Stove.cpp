#include "Stove.h"
#include "Scene.h"

Stove::Stove(GLuint texture_id, glm::vec3 position, float width, float height, GameState* game_state)
: Entity(texture_id, 0.0f, width, height), m_current_dish(NONE), m_game_state(game_state) {
    set_position(position);
    set_scale(glm::vec3(1.0f, 1.8f, 0.0f));
}

void Stove::cook_order() {
    for (Entity* dish : m_game_state->food_queue) {
        if (dish != nullptr && dish->get_dish_state() == RAW) {
            
            dish->set_dish_visible(true);
            dish->set_visible_time_limit(-1.0f);
            dish->set_position(glm::vec3(get_position().x, get_position().y + 0.5f, 0.0f));
            dish->set_dish_state(COOKED);
            
            m_order = dish;
            is_cooking = false;
            Mix_PlayChannel(-1,  m_game_state->cook_sfx, 0);
            
            return;
        }
    }
}

void Stove::finish_order() {
    if (m_game_state->player->get_held_dish() == nullptr) {
        m_game_state->player->set_held_dish(m_order);
        m_order = nullptr;
    }
}

void Stove::interact() {
    if (m_order == nullptr) cook_order();
    else if (!is_cooking) finish_order();
}

#include "LevelA.h"
#include "Utility.h"
#include "Chair.h"
#include "Table.h"
#include "Customer.h"

#define LEVEL_WIDTH 10
#define LEVEL_HEIGHT 10

constexpr char SPRITESHEET_FILEPATH[] = "assets/pichu.png";

unsigned int LEVELA_DATA[] =
{
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 20, 20, 20, 20,
};

LevelA::~LevelA()
{
    delete [] m_game_state.customers;
    delete [] m_game_state.chairs;
    delete [] m_game_state.tables;
    delete    m_game_state.player;
    delete    m_game_state.map;
    Mix_FreeChunk(m_game_state.cook_sfx);
    Mix_FreeChunk(m_game_state.serve_sfx);
    Mix_FreeChunk(m_game_state.bell_sfx);
}

void LevelA::setup_chairs_and_table(int chair_start_index, int chairs_count, int table_index, GLuint table_texture_id,
                            GLuint left_chair_texture_id, GLuint right_chair_texture_id, glm::vec3 table_position ) {
    m_game_state.tables[table_index] = new Table(table_texture_id, table_position, 2.0f, 2.0f);
    
    m_game_state.chairs[chair_start_index] = new Chair(left_chair_texture_id, glm::vec3(table_position.x - 0.8f, table_position.y, 0.0f), 1.0f, 1.0f);
    m_game_state.chairs[chair_start_index + 1] = new Chair(right_chair_texture_id, glm::vec3(table_position.x + 0.8f, table_position.y, 0.0f), 1.0f, 1.0f);
    
    m_game_state.chairs[chair_start_index]->set_paired_chair(m_game_state.chairs[chair_start_index + 1]);
    m_game_state.chairs[chair_start_index]->set_associated_table(m_game_state.tables[table_index]);
    m_game_state.chairs[chair_start_index + 1]->set_paired_chair(m_game_state.chairs[chair_start_index]);
    m_game_state.chairs[chair_start_index + 1]->set_associated_table(m_game_state.tables[table_index]);
}

void LevelA::initialise()
{
    m_game_state.points = 0;
    m_game_state.next_scene_id = -1;
    
    GLuint map_texture_id = Utility::load_texture("assets/cafe-tileset.png");
    m_game_state.map = new Map(LEVEL_WIDTH, LEVEL_HEIGHT, LEVELA_DATA, map_texture_id, 1.0f, 20, 1);
    
    GLuint speech_bubble_texture_id = Utility::load_texture("assets/speech.png");
    
    int player_walking_animation[5][4] =
    {
        { 0, 1, 2, 3 },
        { 4, 5, 6, 7 },
        { 8, 9, 10, 11 },
        { 12, 13, 14, 15 },
        { 16, 17, 18, 19 },
    };
    
    GLuint player_texture_id = Utility::load_texture(SPRITESHEET_FILEPATH);
    
    m_game_state.player = new PlayableCharacter(
                                                player_texture_id,         // texture id
                                                1.5f,                      // speed
                                                glm::vec3(0.0f),              // acceleration
                                                0.0f,                     // jumping power
                                                player_walking_animation,  // animation index sets
                                                0.0f,                      // animation time
                                                4,                         // animation frame amount
                                                0,                         // current animation index
                                                4,                         // animation column amount
                                                5,                         // animation row amount
                                                1.5f,                      // width
                                                1.5f                      // height
                                                );

    m_game_state.player->set_position(glm::vec3(5.0f, -5.0f, 0.0f));
    
    GLuint table_texture_id = Utility::load_texture("assets/table.png");
    GLuint left_chair_texture_id = Utility::load_texture("assets/left_chair.png");
    GLuint right_chair_texture_id = Utility::load_texture("assets/right_chair.png");
    GLuint stove_texture_id = Utility::load_texture("assets/stove.png");
    
    m_game_state.tables = new Table*[TABLES_COUNT];
    m_game_state.chairs = new Chair*[CHAIRS_COUNT];
    
    setup_chairs_and_table(0, CHAIRS_COUNT, 0, table_texture_id, left_chair_texture_id, right_chair_texture_id, glm::vec3(2.5f, -7.0f, 0.0f));
    setup_chairs_and_table(2, CHAIRS_COUNT, 1, table_texture_id, left_chair_texture_id, right_chair_texture_id, glm::vec3(6.8f, -7.0f, 0.0f));
    
    m_game_state.stoves = new Stove*[STOVE_COUNT];
    m_game_state.stoves[0] = new Stove(stove_texture_id, glm::vec3(4.0f, -2.0f, 0.0f), 1.5f, 1.5f, &m_game_state);
    m_game_state.interactables.push_back(m_game_state.stoves[0]);
    
    GLuint caterpie_texture_id = Utility::load_texture("assets/caterpie.png");
    GLuint gulpin_texture_id = Utility::load_texture("assets/gulpin.png");
    GLuint torchic_texture_id = Utility::load_texture("assets/torchic.png");
    
    m_game_state.customers = new Customer*[CUSTOMER_COUNT];
    
    for (int i = 0; i < CUSTOMER_COUNT; i++) {
        m_game_state.customers[i] = new Customer(caterpie_texture_id,         // texture id
                                            1.0f,                      // speed
                                            glm::vec3( 0.0f),              // acceleration
                                            17.0f,                     // jumping power
                                            player_walking_animation,  // animation index sets
                                            0.0f,                      // animation time
                                            4,                         // animation frame amount
                                            0,                         // current animation index
                                            4,                         // animation column amount
                                            5,                         // animation row amount
                                            1.5f,                      // width
                                            1.5f,                      // height
                                            &m_game_state
                                            );
        m_game_state.customers[i]->set_patience(20.0f);
        m_game_state.customers[i]->set_order_threshold(5.0f);
        
    }
    
    m_game_state.customers[0]->set_spawn_threshold(5.0f);
    m_game_state.customers[1]->set_spawn_threshold(10.0f);
    m_game_state.customers[2]->set_spawn_threshold(18.0f);
    m_game_state.customers[3]->set_spawn_threshold(23.0f);
        
    m_game_state.speech = new Entity*[SPEECH_COUNT];
    for (int i = 0; i < SPEECH_COUNT; i++) {
        m_game_state.speech[i] = new Entity(speech_bubble_texture_id,         // texture id
                                            3.0f,                      // speed
                                            glm::vec3(0.0f),              // acceleration
                                            17.0f,                     // jumping power
                                            player_walking_animation,  // animation index sets
                                            0.0f,                      // animation time
                                            4,                         // animation frame amount
                                            0,                         // current animation index
                                            4,                         // animation column amount
                                            5,                         // animation row amount
                                            1.0f,                      // width
                                            1.0f                      // height)
                                            );
        m_game_state.speech[i]->set_scale(glm::vec3(2.0f, 2.0f, 0.0f));
    }
    
    m_game_state.customer_count = CUSTOMER_COUNT;
    
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    
    m_game_state.cook_sfx = Mix_LoadWAV("assets/cook.mp3");
    m_game_state.serve_sfx = Mix_LoadWAV("assets/serve_plate.mp3");
    m_game_state.bell_sfx = Mix_LoadWAV("assets/bell.mp3");
}

float A_time_since_lose = 0.0f;

void LevelA::update(float delta_time)
{
    m_game_state.player->update(delta_time, m_game_state.player, nullptr, 0, m_game_state.map);
    if (m_game_state.player->get_held_dish() != nullptr) m_game_state.player->get_held_dish()->set_position(glm::vec3(m_game_state.player->get_position().x, m_game_state.player->get_position().y + 0.3f, 0.0f));
    
    for (int i = 0; i < STOVE_COUNT; i++) m_game_state.stoves[i]->update();
    for (int i = 0; i < CHAIRS_COUNT; i++) m_game_state.chairs[i]->update();
    for (int i = 0; i < TABLES_COUNT; i++) m_game_state.tables[i]->update();
    for (int i = 0; i < CUSTOMER_COUNT; i++) {
        m_game_state.customers[i]->update(delta_time, m_game_state.chairs, CHAIRS_COUNT, m_game_state.map, m_game_state.customer_queue);
        glm::vec3 customer_position = m_game_state.customers[i]->get_position();
        m_game_state.speech[i]->set_position(glm::vec3(customer_position.x, customer_position.y + 1.0f, 0));
        m_game_state.speech[i]->update(delta_time, m_game_state.player, nullptr, 0, m_game_state.map);
    }
    
    for (size_t i = 0; i < m_game_state.food_queue.size(); i++) m_game_state.food_queue[i]->update(delta_time, m_game_state.player, nullptr, 0, m_game_state.map);
    
    bool game_over = true;
    for (int i = 0; i < CUSTOMER_COUNT; i++) {
        game_over = game_over && (m_game_state.customers[i]->get_customer_state() == GONE && m_game_state.customers[i]->get_position() == glm::vec3(0.0f, -9.0f, 0.0f));
    }
    
    if (game_over) {
        if (m_game_state.points >= WIN) {
            m_game_state.next_scene_id = 4;
            m_game_state.go_next = true;
        }
        else {
            m_game_state.next_scene_id = 1;
            A_time_since_lose += delta_time;
            if (A_time_since_lose >= 2.0f) m_game_state.go_next = true;
        }
    }
}

void LevelA::render(ShaderProgram *program)
{
    m_game_state.map->render(program);
    for (int i = 0; i < STOVE_COUNT; i++) m_game_state.stoves[i]->render(program);
    for (int i = 0; i < CHAIRS_COUNT; i++) m_game_state.chairs[i]->render(program);
    m_game_state.player->render(program);
    
    for (int i = 0; i < TABLES_COUNT; i++) m_game_state.tables[i]->render(program);
    for (int i = 0; i < CUSTOMER_COUNT; i++) {
        if  ((m_game_state.customers[i]->get_customer_state() == GONE && m_game_state.customers[i]->get_position() != glm::vec3(0.0f, -9.0f, 0.0f)) || (m_game_state.customers[i]->get_customer_state() != UNSPAWNED && m_game_state.customers[i]->get_customer_state() != GONE)) {
            m_game_state.customers[i]->render(program);
            if (m_game_state.customers[i]->get_show_speech()) {
                m_game_state.speech[i]->set_speech_bubble(m_game_state.customers[i]->get_speech());
                m_game_state.speech[i]->render(program);
            }
        }
    }
    
    for (size_t i = 0; i < m_game_state.food_queue.size(); i++) {
        if (m_game_state.food_queue[i]->get_dish_visible()) m_game_state.food_queue[i]->render(program);
    }
}

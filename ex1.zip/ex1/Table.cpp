#include "Table.h"

Table::Table(GLuint texture_id, glm::vec3 position, float width, float height)
: Entity(texture_id, 0.0f, width, height) {
    set_position(position);
    set_scale(glm::vec3(1.0f, 1.4f, 0.0f));

}

void Table::place_food(Entity* food) {
    if (!has_food()) {
        m_food = food;
        m_food->set_position(get_position());
    }
}

void Table::remove_food() {
    m_food = nullptr;
}

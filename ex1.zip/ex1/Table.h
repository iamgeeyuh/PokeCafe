#ifndef TABLE_H
#define TABLE_H

#include "Entity.h"

class Table : public Entity {
private:
    Entity* m_food = nullptr;

public:
    // Constructor
    Table(GLuint texture_id, glm::vec3 position, float width, float height);

    // Methods
    void place_food(Entity* food);
    void remove_food();
    
    // Getters
    Entity* const get_food() const { return m_food; }
    bool const has_food() const { return m_food != nullptr; }
};

#endif // TABLE_H

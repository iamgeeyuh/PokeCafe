#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "Entity.h"
#include "Chair.h"
#include "Table.h"
#include "Utility.h"
#include <cstdlib>

enum CustomerState { UNSPAWNED, WAITING_IN_LINE, ORDERING, WAITING_TO_ORDER, WAITING_FOR_FOOD, EATING, GONE };

struct GameState;

class Customer : public Entity {
private:
    
    Chair* m_target_chair = nullptr;
    
    Chair* find_available_chair(Chair** chairs, int chair_count);
    
    void path_to_chair(float delta_time);
    void path_to_position(float delta_time, glm::vec3 target_position);
    void serve_food();
    void order_random_food();
    
    CustomerState m_customer_state = UNSPAWNED;
    
    float m_time_since_spawn = 0.0f;
    float m_spawn_threshold;
    
    float m_time_since_sit = 0.0f;
    float m_order_threshold;
    
    glm::vec3 m_queue_position;
    
    float m_time_since_waiting = 0.0f;
    float m_patience_threshold = 0.0f;
    
    bool show_speech = false;
    SpeechBubbles speech_bubble = HAPPY;
    
    float m_time_since_emote = 0.0f;
    float m_emote_threshold = 0.0f;
    
    DishType m_food_order = NONE;
    
    GameState* m_game_state;
    
    bool is_gulpin = false;
    int num_gulpin_meals = 0;
   
    GLuint m_burger_texture_id = Utility::load_texture("assets/burger.png");
    GLuint m_cake_texture_id = Utility::load_texture("assets/cake.png");
    GLuint m_pie_texture_id = Utility::load_texture("assets/pie.png");
    
public:
    // Constructor
    Customer(GLuint texture_id, float speed, glm::vec3 acceleration, float jump_power, int walking[5][4], float animation_time,
             int animation_frames, int animation_index, int animation_cols,
             int animation_rows, float width, float height, GameState* game_state);
    
    
    void update(float delta_time, Chair** chairs, int chair_count, Map *map, std::vector<Customer*>& queue);
    
    void interact() override;
    
    // Setters
    void set_customer_state(CustomerState new_customer_state) { m_customer_state = new_customer_state; }
    void set_spawn_threshold(float new_spawn_threshold) { m_spawn_threshold = new_spawn_threshold; }
    void set_order_threshold(float new_order_threshold) { m_order_threshold = new_order_threshold; }
    void set_queue_position(glm::vec3 new_queue_position) { m_queue_position = new_queue_position; }
    void set_patience(float new_patience) { m_patience_threshold = new_patience; }
    void set_show_speech(bool new_show_speech) {show_speech = new_show_speech;}
    void set_speech(SpeechBubbles speech) {speech_bubble = speech;}
    void set_is_gulpin(bool new_is_gulpin) {is_gulpin = new_is_gulpin;}
    void set_num_gulpin_meals() { num_gulpin_meals = 2 + (std::rand() % 3); }
    
    // Getters
    Chair* const get_target_chair() const { return m_target_chair; }
    CustomerState const get_customer_state() const { return m_customer_state; }
    float get_patience() const { return m_patience_threshold; }
    bool get_show_speech() const {return show_speech;}
    SpeechBubbles get_speech() const {return speech_bubble;}
};

#endif // CUSTOMER_H

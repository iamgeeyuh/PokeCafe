#pragma once
#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#define GL_GLEXT_PROTOTYPES 1
#include <SDL_mixer.h>
#include <SDL.h>
#include <SDL_opengl.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"
#include "Util.h"
#include "Entity.h"
#include "PlayableCharacter.h"
#include "Map.h"
#include "Chair.h"
#include "Table.h"
#include "Customer.h"
#include <vector>
#include "Stove.h"

/**
    The game's state is now part of the Scene class.
*/
struct GameState
{
    // ————— GAME OBJECTS ————— //
    Map *map;
    PlayableCharacter *player;
    Stove **stoves;
    Customer **customers;
    Chair **chairs;
    Table **tables;
    Entity **speech;
    Entity *background;
    
    std::vector<Entity*> interactables;
    std::vector<Customer*> customer_queue;
    std::vector<Entity*> food_queue;
    int max_queue_size = 3;
    
    int points = 0;
    
    int customer_count;
    
    bool go_next = false;

    // ————— POINTERS TO OTHER SCENES ————— //
    int next_scene_id;
    
    Mix_Chunk *cook_sfx;
    Mix_Chunk *serve_sfx;
    Mix_Chunk *bell_sfx;
};

class Scene {
protected:
    GameState m_game_state;
    
public:
    // ————— ATTRIBUTES ————— //
    int m_number_of_customers = 3;
    int m_number_of_chairs = 4;
    int m_number_of_tables = 2;
    int m_number_of_interactables = 3;
    
    // ————— METHODS ————— //
    virtual void initialise() = 0;
    virtual void update(float delta_time) = 0;
    virtual void render(ShaderProgram *program) = 0;
    
    // ————— GETTERS ————— //
    GameState const get_state() const { return m_game_state; }
    int const get_number_of_customers() const { return m_number_of_customers; }
    int const get_number_of_chairs() const { return m_number_of_chairs; }
    int const get_number_of_tables() const { return m_number_of_tables; }
    int const get_number_of_interactables() const { return m_number_of_interactables; }
};

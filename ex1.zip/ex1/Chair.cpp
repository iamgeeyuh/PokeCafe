#include "Chair.h"

Chair::Chair(GLuint texture_id, glm::vec3 position, float width, float height)
    : Entity(texture_id, 0.0f, width, height){
    set_position(position);
    set_scale(glm::vec3(1.0f, 1.8f, 0.0f));
}


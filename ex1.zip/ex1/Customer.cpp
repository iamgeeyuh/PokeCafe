#include "Customer.h"
#include <cstdlib>
#include "Scene.h"
#include "Utility.h"

// Constructor
Customer::Customer(GLuint texture_id, float speed, glm::vec3 acceleration, float jump_power, int walking[5][4], float animation_time,
                   int animation_frames, int animation_index, int animation_cols,
                   int animation_rows, float width, float height, GameState* game_state)
: Entity(texture_id, speed, acceleration, jump_power, walking, animation_time, animation_frames,
         animation_index, animation_cols, animation_rows, width, height), m_game_state(game_state) {
    set_position(glm::vec3(-1.0f, -15.0f, 0.0f));
    set_num_gulpin_meals();
    set_customer_state(UNSPAWNED);
}

Chair* Customer::find_available_chair(Chair** chairs, int chair_count) {
    for (int i = 0; i < chair_count; ++i) {
        if (chairs[i] && !chairs[i]->is_occupied()) {
            return chairs[i];
        }
    }
    return nullptr;
}

void Customer::path_to_chair(float delta_time) {
    if (!m_target_chair) return;
    
    glm::vec3 chair_position = m_target_chair->get_position();
    glm::vec3 direction = chair_position - get_position();
    
    if (glm::abs(direction.x) > 0.1f) {
        if (direction.x > 0) move_right();
        else move_left();
    } else {
        set_movement(glm::vec3(0, get_movement().y, 0));
    }
    
    if (glm::abs(direction.y) > 0.1f) {
        if (direction.y > 0) move_up();
        else move_down();
    } else {
        set_movement(glm::vec3(get_movement().x, 0, 0));
    }
    
    if (glm::abs(direction.x) > 0.1f && glm::abs(direction.y) > 0.1f) {
        if (direction.x > 0 && direction.y > 0) move_diagonal_up();
        else if (direction.x > 0 && direction.y < 0) move_diagonal_down();
        else if (direction.x < 0 && direction.y > 0) move_diagonal_up();
        else move_diagonal_down();
    }
    
    set_position(get_position() + get_movement() * get_speed() * delta_time);
    
    if (glm::length(direction) < 0.1f) {
        set_position(chair_position);
        m_target_chair->set_occupied(true);
        set_movement(glm::vec3(0.0f));
    }
}

void Customer::path_to_position(float delta_time, glm::vec3 target_position) {
    glm::vec3 direction = target_position - get_position();
    
    if (glm::abs(direction.x) > 0.1f) {
        if (direction.x > 0) move_right();
        else move_left();
    } else {
        set_movement(glm::vec3(0, get_movement().y, 0));
    }
    
    if (glm::abs(direction.y) > 0.1f) {
        if (direction.y > 0) move_up();
        else move_down();
    } else {
        set_movement(glm::vec3(get_movement().x, 0, 0));
    }
    
    if (glm::abs(direction.x) > 0.1f && glm::abs(direction.y) > 0.1f) {
        if (direction.x > 0 && direction.y > 0) move_diagonal_up();
        else if (direction.x > 0 && direction.y < 0) move_diagonal_down();
        else if (direction.x < 0 && direction.y > 0) move_diagonal_up();
        else move_diagonal_down();
    }
    
    set_position(get_position() + get_movement() * get_speed() * delta_time);
}

void Customer::update(float delta_time, Chair** chairs, int chair_count, Map *map, std::vector<Customer*>& queue) {
    if (m_emote_threshold != 0.0f) {
        m_time_since_emote += delta_time;
        if (m_time_since_emote >= m_emote_threshold) {
            set_show_speech(false);
            m_emote_threshold = 0.0f;
            m_time_since_emote = 0.0f;
        }
    }
    switch (get_customer_state()) {
        case UNSPAWNED:
            m_time_since_spawn += delta_time;
            if (m_time_since_spawn >= m_spawn_threshold && queue.size() < 3) {
                queue.push_back(this);
                set_customer_state(WAITING_IN_LINE);
                set_queue_position(glm::vec3(0.0f, -6.0f - queue.size() + 1, 0.0f));
                Mix_PlayChannel(-1,  m_game_state->bell_sfx, 0);
            }
            break;
        case WAITING_IN_LINE:
            if (glm::length(get_position() - m_queue_position) > 0.15f) {
                path_to_position(delta_time, m_queue_position);
            }
            else {
                set_position(m_queue_position);
                set_movement(glm::vec3(0.0f));
                set_animation_index(0);
                face_side();
                set_scale(glm::vec3(std::abs(get_scale().x), std::abs(get_scale().y), 0.0f));
                
                m_time_since_waiting += delta_time;
                if (m_time_since_waiting >= m_patience_threshold) {
                    auto it = std::find(queue.begin(), queue.end(), this);
                    if (it != queue.end()) {
                        queue.erase(it);
                    }
                    for (size_t i = 0; i < queue.size(); ++i) queue[i]->set_queue_position(glm::vec3(0.0f, -6.0f - i, 0.0f));
                    set_customer_state(GONE);
                    set_show_speech(true);
                    set_speech(ANGRY);
                    break;
                }
            }
            
            break;
        case ORDERING: {
            if (!m_target_chair) {
                m_target_chair = find_available_chair(chairs, chair_count);
                if (!m_target_chair) {
                    set_customer_state(WAITING_IN_LINE);
                    set_show_speech(true);
                    set_speech(THINK);
                    m_time_since_emote = 0.0f;
                    m_emote_threshold = 1.0f;
                    return;
                }
                set_show_speech(true);
                set_speech(HAPPY);
                m_time_since_emote = 0.0f;
                m_emote_threshold = 3.0f;
            }
            
            auto it = std::find(queue.begin(), queue.end(), this);
            if (it != queue.end()) {
                queue.erase(it);
                for (size_t i = 0; i < queue.size(); ++i) queue[i]->set_queue_position(glm::vec3(0.0f, -6.0f - i, 0.0f));
            }
            
            if (m_target_chair) {
                m_target_chair->set_occupied(true);
                if (m_target_chair->get_paired_chair()) m_target_chair->get_paired_chair()->set_occupied(true);
                
                glm::vec3 chair_position = m_target_chair->get_position();
                if (glm::length(get_position() - chair_position) > 0.15f) {
                    path_to_position(delta_time, chair_position);
                } else {
                    set_position(chair_position);
                    set_movement(glm::vec3(0.0f));
                    
                    set_animation_index(0);
                    face_side();
                    
                    Table* associated_table = m_target_chair->get_associated_table();
                    if (associated_table) {
                        glm::vec3 table_position = associated_table->get_position();
                        face_side();
                        if (table_position.x > chair_position.x) set_scale(glm::vec3(std::abs(get_scale().x), std::abs(get_scale().y), 0.0f));
                        else set_scale(glm::vec3(-std::abs(get_scale().x), std::abs(get_scale().y), 0.0f));
                        
                    }
                    m_time_since_sit += delta_time;
                    if (m_time_since_sit >= m_order_threshold) {
                        set_customer_state(WAITING_TO_ORDER);
                        m_time_since_waiting = 0.0f;
                    }
                }
            }
        }
            break;
        case WAITING_TO_ORDER:
            set_show_speech(true);
            set_speech(ALERT);
            m_time_since_waiting += delta_time;
            if (m_time_since_waiting >= m_patience_threshold) {
                set_customer_state(GONE);
                set_show_speech(true);
                set_speech(ANGRY);
                m_target_chair->set_occupied(false);
                if (m_target_chair->get_paired_chair()) m_target_chair->get_paired_chair()->set_occupied(false);
            }
            break;
        case WAITING_FOR_FOOD:
            m_time_since_waiting += delta_time;
            if (m_time_since_waiting >= m_patience_threshold) {
                set_customer_state(GONE);
                set_show_speech(true);
                set_speech(ANGRY);
                m_target_chair->set_occupied(false);
                if (m_target_chair->get_paired_chair()) m_target_chair->get_paired_chair()->set_occupied(false);
            }
            break;
        case EATING:
            m_time_since_sit += delta_time;
            if (m_time_since_sit >= m_order_threshold) {
                set_customer_state(GONE);
                set_show_speech(true);
                set_speech(GOLD);
                m_emote_threshold = 2.0f;
                m_target_chair->get_associated_table()->get_food()->set_dish_visible(false);
                m_target_chair->get_associated_table()->get_food()->set_visible_time_limit(0.0f);
                m_target_chair->get_associated_table()->remove_food();
                m_game_state->points = m_game_state->points + 1;
                if (is_gulpin && num_gulpin_meals > 0) {
                    m_emote_threshold = 2.0f;
                    m_time_since_sit = 0.0f;
                    set_customer_state(ORDERING);
                } else {
                    m_emote_threshold = 0.0f;
                    m_target_chair->set_occupied(false);
                    if (m_target_chair->get_paired_chair()) m_target_chair->get_paired_chair()->set_occupied(false);
                }
            }
            break;
        case GONE:
            if (glm::length(get_position() - glm::vec3(0.0f, -9.0f, 0.0f)) > 0.15f) path_to_position(delta_time, glm::vec3(0.0f, -9.0f, 0.0f));
            else {
                set_position(glm::vec3(0.0f, -9.0f, 0.0f));
                set_movement(glm::vec3(0.0f));
            }
            break;
    }
    
    Entity::update(delta_time, nullptr, nullptr, 0, map);
}

void Customer::interact() {

    switch (get_customer_state()) {
        case WAITING_IN_LINE:
            set_customer_state(ORDERING);
            m_target_chair = nullptr;
            break;
        case WAITING_TO_ORDER:
            if (is_gulpin) num_gulpin_meals--;
            order_random_food();
            set_show_speech(false);
            set_customer_state(WAITING_FOR_FOOD);
            m_time_since_waiting = 0.0f;
            break;
        case WAITING_FOR_FOOD:
            serve_food();
            break;
        default:
            break;
    }
}

void Customer::order_random_food() {
    int random_index = rand() % static_cast<int>(DishType::NONE);
    m_food_order = static_cast<DishType>(random_index);
    
    GLuint texture_id = m_food_order == BURGER ? m_burger_texture_id : m_food_order == CAKE ? m_cake_texture_id : m_pie_texture_id;
    
    Entity* order = new Entity(texture_id, 0.0f, 1.0f, 1.0f);
    
    m_game_state->food_queue.push_back(order);
    
    order->set_dish_type(m_food_order);
    order->set_position(glm::vec3(get_position().x, get_position().y + 0.7f, 0));
    order->set_scale(glm::vec3(0.5f));
    order->set_time_since_visible(0.0f);
    order->set_visible_time_limit(2.0f);
    order->set_dish_visible(true);
}

void Customer::serve_food() {
    Entity* dish = m_game_state->player->get_held_dish();
    if (dish != nullptr && dish->get_dish_type() == m_food_order) {
        Mix_PlayChannel(-1,  m_game_state->serve_sfx, 0);
        m_target_chair->get_associated_table()->place_food(dish);
        m_game_state->player->set_held_dish(nullptr);
        set_customer_state(EATING);
        set_speech(HAPPY);
        set_show_speech(true);
        m_emote_threshold = 2.0f;
        m_time_since_emote = 0.0f;
        m_time_since_sit = 0.0f;
    }
}

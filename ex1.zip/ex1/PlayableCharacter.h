#ifndef PLAYABLE_CHARACTER_H
#define PLAYABLE_CHARACTER_H

#include "Entity.h"
#include <vector>

class PlayableCharacter : public Entity {
private:
    Entity* m_held_dish = nullptr;
    
public:
    PlayableCharacter(GLuint texture_id, float speed, glm::vec3 acceleration, float jump_power, int walking[5][4], float animation_time,
                      int animation_frames, int animation_index, int animation_cols,
                      int animation_rows, float width, float height);

    void interact_with_nearest(std::vector<Entity*>& interactables);
    
    Entity* get_held_dish() const {return m_held_dish;}
    void set_held_dish(Entity* new_dish) {m_held_dish = new_dish;}
};

#endif // PLAYABLE_CHARACTER_H

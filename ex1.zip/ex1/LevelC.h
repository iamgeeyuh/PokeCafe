#include "Scene.h"

class LevelC : public Scene {
public:
    int NPC_COUNT = 1;
    int CUSTOMER_COUNT = 7;
    int CHAIRS_COUNT = 4;
    int TABLES_COUNT = 2;
    int SPEECH_COUNT = 7;
    int STOVE_COUNT = 1;
    int WIN = 5;
    
    ~LevelC();
    
    void initialise() override;
    void update(float delta_time) override;
    void render(ShaderProgram *program) override;
    void setup_chairs_and_table(int chair_start_index, int chairs_count, int table_index, GLuint table_texture_id,
                                GLuint left_chair_texture_id, GLuint right_chair_texture_id, glm::vec3 table_position );
};

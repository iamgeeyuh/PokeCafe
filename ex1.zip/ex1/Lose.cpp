#include "Lose.h"
#include "Utility.h"

#define LEVEL_WIDTH 60
#define LEVEL_HEIGHT 33

constexpr char SPRITESHEET_FILEPATH[] = "assets/lose.png";

Lose::~Lose()
{
    delete    m_game_state.background;
}

void Lose::initialise()
{
    m_game_state.go_next = true;
    
    m_game_state.next_scene_id = -1;
    
    GLuint player_texture_id = Utility::load_texture(SPRITESHEET_FILEPATH);
    
    m_game_state.background = new Entity();
    
    m_game_state.background->set_texture_id(player_texture_id);
    m_game_state.background->set_position(glm::vec3(0.0f, 0.0f, 0.0f));
    m_game_state.background->set_scale(glm::vec3(25.0f, 16.0f, 0.0f));
    m_game_state.background->update();
}

void Lose::update(float delta_time)
{
    if (m_game_state.background->get_next_level()) m_game_state.next_scene_id = 3;
}

void Lose::render(ShaderProgram *program)
{
    m_game_state.background->render(program);
}

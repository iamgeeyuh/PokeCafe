#ifndef CHAIR_H
#define CHAIR_H

#include "Entity.h"

class Table;

class Chair : public Entity {
private:
    bool m_is_occupied = false;
    Chair* m_paired_chair = nullptr;
    Table* m_associated_table = nullptr; 

public:
    // Constructor
    Chair(GLuint texture_id, glm::vec3 position, float width, float height);

    // Getters and Setters
    bool const is_occupied() const { return m_is_occupied; }
    void const set_occupied(bool occupied) { m_is_occupied = occupied; }

    void const set_paired_chair(Chair* paired_chair) { m_paired_chair = paired_chair; }
    Chair* const get_paired_chair() const { return m_paired_chair; }

    void const set_associated_table(Table* table) { m_associated_table = table; }
    Table* const get_associated_table() const { return m_associated_table; }
};

#endif // CHAIR_H

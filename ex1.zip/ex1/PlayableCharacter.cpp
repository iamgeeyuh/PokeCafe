#include "PlayableCharacter.h"
#include <limits>

PlayableCharacter::PlayableCharacter(GLuint texture_id, float speed, glm::vec3 acceleration, float jump_power, int walking[5][4], float animation_time,
                                     int animation_frames, int animation_index, int animation_cols,
                                     int animation_rows, float width, float height)
: Entity(texture_id, speed, acceleration, jump_power, walking, animation_time, animation_frames,
         animation_index, animation_cols, animation_rows, width, height) {}

void PlayableCharacter::interact_with_nearest(std::vector<Entity*>& interactables) {
    Entity* closest = nullptr;
    float closest_distance = std::numeric_limits<float>::max();
    
    for (Entity* interactable : interactables) {
        float distance = glm::length(get_position() - interactable->get_position());
        if (distance < closest_distance) {
            closest_distance = distance;
            closest = interactable;
        }
    }
    
    
    if (closest && closest_distance < 1.0f) {
        closest->interact();
    }
}
